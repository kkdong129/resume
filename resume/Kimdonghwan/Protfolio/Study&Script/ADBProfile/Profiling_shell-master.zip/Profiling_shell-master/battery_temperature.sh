#!/bin/bash

#battery_temperature.sh time
echo "temperature: n, Celsius degree(℃)" >> batterytemp.txt
increase=0
while [ $increase -lt $1 ];
do
tt=`adb shell dumpsys battery|grep "temperature"`
ts=${tt: -4}
temperature=`expr $ts / 10`
echo `date +"%T temperature: "` $temperature >> batterytemp.txt
sleep 60; #unit: seconds
increase=$(($increase+1))
if [ $increase -eq $1 ];
	then
		echo "" >> batterytemp.txt
		break
fi
done